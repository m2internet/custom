#include "algo-gate-api.h"

extern unsigned char *hodl_scratchbuf;

bool register_hodl_algo ( algo_gate_t* gate );

